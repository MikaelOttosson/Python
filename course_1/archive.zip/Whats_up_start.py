#
#

def main():
	print "Whats up?"

if __name__ == '__main__':
	main()
