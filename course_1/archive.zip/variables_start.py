# Variables

# Declaration and print 
f = 0;
print f

# Redeclaration of variables
# f = "abc"
# print f


# Error example
# print "string type " + str(123)


# Globals
# def someFunction():
# 	global f
# 	f = "def" # Global f
# 	print f

# someFunction()
# print f

del f
print f # No value generates error